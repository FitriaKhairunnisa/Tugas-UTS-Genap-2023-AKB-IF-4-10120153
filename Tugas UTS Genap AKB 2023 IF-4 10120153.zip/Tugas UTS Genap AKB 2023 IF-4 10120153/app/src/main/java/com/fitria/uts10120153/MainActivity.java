package com.fitria.uts10120153;
//Fitria Khairunnisa syahputri Joisangadji - 10120153 - IF-4 - dheakhairunnisa8@gmail.com

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}